package data.base;
import java.util.Random;


public enum Country {
    Ukraine("ukr"),
    Spain("spn"),
    Germany("ger"),
    Poland("pol");
    private String name;
    protected static Random random = new Random();

    Country(String name) {
        this.name = name;
    }

    public static Country getRandomCountry() {
        switch (random.nextInt(4)) {
            case 0: return Country.Ukraine;
            case 1: return Country.Spain;
            case 2: return Country.Germany;
            case 3: return Country.Poland;

        }
        return Country.Ukraine;
    }


    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Country{" +
                "name='" + name + '\'' +
                '}';
    }
}