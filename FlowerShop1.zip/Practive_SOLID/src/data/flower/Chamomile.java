package data.flower;

import data.base.Color;

import data.base.Country;

public class Chamomile extends Flower {

    public Chamomile(Color color, Country country, float price, int length) {
        super(color, country, price, length);
    }

    public static Chamomile getRandomChamolite() {
        return new Chamomile(getRandomColor(), getRandomCountry(), getRandomPrice(), getRandomLength());
    }

    @Override
    public String toString() {
        return "Chamomile{" +
                "color=" + color +
                "country=" + country +
                ", price=" + price +
                ", length=" + length +
                '}';
    }
}