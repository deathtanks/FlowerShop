package data.flower;

import data.base.Color;

import data.base.Country;

public class Tulip extends Flower {

    public Tulip(Color color, Country country, float price, int length) {
        super(color, country, price, length);
    }

    public static Tulip getRandomTulip() {
        return new Tulip(getRandomColor(), getRandomCountry(), getRandomPrice(), getRandomLength());
    }

    @Override
    public String toString() {
        return "Tulip{" +
                "color=" + color +
                "country=" + country +
                ", price=" + price +
                ", length=" + length +
                '}';
    }
}
