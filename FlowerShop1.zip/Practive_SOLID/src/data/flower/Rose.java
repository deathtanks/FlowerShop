package data.flower;

import data.base.Color;

import data.base.Country;

public class Rose extends Flower {

    public Rose(Color color, Country country, float price, int length) {
        super(color, country, price, length);
    }

    public static Rose getRandomRose() {
        return new Rose(getRandomColor(), getRandomCountry(), getRandomPrice(), getRandomLength());
    }

    @Override
    public String toString() {
        return "Rose{" +
                "color=" + color +
                "country=" + country +
                ", price=" + price +
                ", length=" + length +
                '}';
    }
}
